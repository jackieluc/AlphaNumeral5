import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

public class GroupManager {
	private static GroupManager instance = new GroupManager();
	public final static int port = 5000;
	public ConcurrentHashMap<String, GroupCommunicator> comms = new ConcurrentHashMap<String, GroupCommunicator>();
	public Object hashLock = new Object();
	public Object electionLock = new Object();
	public ServerSocket socket;
	public String ip;
	public Election election;
	public String leader_ip;
	//public Server server;
	
	private GroupManager() {
		try {
			ip = InetAddress.getLocalHost().getHostAddress();
			System.out.println("Group manager ip: " + ip);
			socket = new ServerSocket(port);
		} catch (IOException e) {
			System.out.println("Could not start group manager");
			System.exit(0);
		}
	}
	
	public static GroupManager getInstance() {
		return instance;
	}
	
	public void initialize(String ip) {
		GroupCommunicator gc = new GroupCommunicator(ip);
		comms.put(ip, gc);
		System.out.println(ip);
		// Connect to group manager with ip
		if(!gc.connect()) {
			System.out.println("Failed to connect");
			System.exit(0);
		}
		
		System.out.println("Waiting for group manager ips...");
		try {
			// Request group manager ips
			gc.write(new ConnectCommand());
			
			// Receive group manager ips
			ConnectCommand command = (ConnectCommand)gc.read();
			
			// Add group managers
			command.read();
		} catch (ClassNotFoundException e) {
			System.out.println("Group manager connection lost");
			System.exit(0);
		} catch (IOException e) {
			System.out.println("Group manager connection lost");
			System.exit(0);
		}
		System.out.println("Added group managers");
		
		// Start group communicator
		new Thread(gc).start();
	}
	
	public void election(String ip) {
		synchronized(electionLock) {
			if(election == null) {
				election = new Election();
			}
			if(!election.check(ip)) {
				multicast(new ElectionCommand(election.update(ip)));
			}
		}
	}
	
	public void setLeader(String ip) {
		synchronized(electionLock) {
			election = null;
		}
		synchronized(hashLock) {
			if(ip.equals(this.ip)) {
				// Inform server it's leader
				// Send ip to proxy
			} else {
				comms.get(ip).leader = true;
			}
		}
	}
	
	public void add(ArrayList<String> ips) {
		synchronized(hashLock) {
			for(String ip : ips) {
				if(!comms.containsKey(ip)) {
					GroupCommunicator gc = new GroupCommunicator(ip);
					comms.put(ip, gc);
					new Thread(gc).start();
				}
			}
		}
	}
	
	public void run() {
		Socket temp;
		String ip;
		while(true) {
			try {
				System.out.println("Waiting for connections...");
				temp = socket.accept();
				ip = temp.getInetAddress().getHostAddress();
				
				synchronized(hashLock) {
					GroupCommunicator gc;
					
					// If a new group communicator connected, add it
					if((gc = comms.get(ip)) == null) {
						gc = new GroupCommunicator(ip);
					}
					
					// Try and connect
					if(gc.connect(temp)) {
						new Thread(gc).start();
					}
				}
			} catch (IOException e) {
				// TODO: recreate server socket?
			}
		}
	}
	
	public void multicast(Object command) {
		synchronized(hashLock) {
			for(GroupCommunicator gc : comms.values()) {
				gc.write(command);
			}
		}
	}
	
	public void toServer(Object command) {
		// TODO: Connect server to group manager
		//server.receive(command);
	}
	
	public ArrayList<String> getGroupManagers() {
		ArrayList<String> gms;
		synchronized(hashLock) {
			gms = new ArrayList<String>(comms.keySet());
		}
		return gms;
	}
	
	public static void main(String[] args) {
		GroupManager gm = GroupManager.getInstance();
		if(args.length > 0) {
			gm.initialize(args[0]);
		}
		gm.election(gm.ip);
		gm.run();
	}
}
