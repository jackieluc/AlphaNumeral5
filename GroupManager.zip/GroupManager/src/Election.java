/*
Change election to set a new leader once time is up,
however, have group managers detect if they are still
connected to the system
*/


public class Election {
	public String current_leader = "";
	public Thread timeout;
	public long time = 10000;
	
	public Election() {
		timeout = new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("Election start");
				try {
					Thread.sleep(time);
					if(current_leader.equals(GroupManager.getInstance().ip)) {
						GroupManager.getInstance().multicast(new LeaderCommand(current_leader));
						leader();
					}
					Thread.sleep(time);
					System.out.println("Election end, no leader");
				} catch (InterruptedException e) {
					System.out.println("Election end, new leader: " + current_leader);
				}
			}
		});
		timeout.start();
	}
	
	public boolean check(String ip) {
		return current_leader.equals(ip);
	}
	
	public String update(String ip) {
		if(current_leader.compareTo(ip) < 0) {
			current_leader = ip;
		}
		return current_leader;
	}
	
	public void leader() {
		timeout.interrupt();
		GroupManager gm = GroupManager.getInstance();
		gm.setLeader(current_leader);
	}
}
