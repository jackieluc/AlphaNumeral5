import java.util.ArrayList;

public class ConnectCommand extends GroupCommand {
	public ArrayList<String> ips;
	
	public void write(ArrayList<String> ips) {
		this.ips = ips;
	}
	
	public void read() {
		GroupManager gm = GroupManager.getInstance();
		gm.add(ips);
	}
}
