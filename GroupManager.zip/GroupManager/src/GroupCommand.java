import java.io.Serializable;

public abstract class GroupCommand implements Serializable {
	
}
