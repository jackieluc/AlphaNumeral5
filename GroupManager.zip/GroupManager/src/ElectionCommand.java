
public class ElectionCommand extends GroupCommand {
	public String ip;
	
	public ElectionCommand(String ip) {
		this.ip = ip;
	}
	
	public void read() {
		GroupManager gm = GroupManager.getInstance();
		gm.election(ip);
	}
}
