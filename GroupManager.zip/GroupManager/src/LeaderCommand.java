
public class LeaderCommand extends GroupCommand {
	public String ip;
	
	public LeaderCommand(String ip) {
		this.ip = ip;
	}
	
	public void read() {
		GroupManager gm = GroupManager.getInstance();
		gm.election.leader();
	}
}
