import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

public class GroupCommunicator implements Runnable {
	public String ip;
	public Socket socket;
	public ObjectInputStream input;
	public ObjectOutputStream output;
	public GroupManager gm;
	public boolean leader = false;
	
	public GroupCommunicator(String ip) {
		this.ip = ip;
		gm = GroupManager.getInstance();
	}
	
	public boolean isAlive() {
		return !(socket == null);
	}
	
	@Override
	public void run() {
		if(socket == null) {
			if(!connect()) {
				// Connection failed
				return;
			}
		}
		
		Object command = null;
		while(true) {
			try {
				command = input.readObject();
				if(command instanceof GroupCommand) {
					respond((GroupCommand)command);
				}
			} catch (ClassNotFoundException e) {
				// Keep reading
			} catch (IOException e) {
				// Connection failed
				reset();
				if(leader) {
					leader = false;
					gm.election(gm.ip);
				}
				return;
			}
		}
	}
	
	public boolean connect() {
		try {
			socket = new Socket(ip, GroupManager.port);
			output = new ObjectOutputStream(socket.getOutputStream());
			output.flush();
			input = new ObjectInputStream(socket.getInputStream());
			System.out.println("Connected to " + socket.toString());
			return true;
		} catch (IOException e) {
			reset();
			return false;
		}
	}
	
	public boolean connect(Socket socket) {
		try {
			this.socket = socket;
			output = new ObjectOutputStream(socket.getOutputStream());
			output.flush();
			input = new ObjectInputStream(socket.getInputStream());
			System.out.println("Connected to " + socket.toString());
			return true;
		} catch (IOException e) {
			reset();
			return false;
		}
	}
	
	public void write(Object command) {
		try {
			output.writeObject(command);
		} catch (IOException e) {
			// TODO
		}
	}
	
	public Object read() throws IOException, ClassNotFoundException {
		return input.readObject();
	}
	
	public void respond(GroupCommand command) {
		System.out.println(command.toString());
		if(command instanceof ConnectCommand) {
			((ConnectCommand)command).write(gm.getGroupManagers());
			write(command);
		} else if(command instanceof ElectionCommand) {
			((ElectionCommand)command).read();
		} else if(command instanceof LeaderCommand) {
			((LeaderCommand)command).read();
		}
	}
	
	/*public void respond(Command command) {
		
	}*/
	
	public void reset() {
		try {
			socket.close();
		} catch (IOException e) {
			// Something went wrong closing socket, set everything to null
			input = null;
			output = null;
			socket = null;
		}
	}
}
